//
//  game_stats.swift
//  Shot Tracker
//
//  Created by user150437 on 1/17/19.
//  Copyright © 2019 Greg Brooks. All rights reserved.
//
import UIKit

class Game_Stats: UIViewController {
    let backGroundImageView = UIImageView()
    
    var homeShotTotal: Int = 0
    var homeGoals: Int = 0
    var awayShotTotal: Int = 0
    var awayGoals: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setBackground()
            }
    
    func setBackground(){
        view.addSubview(backGroundImageView)
        backGroundImageView.translatesAutoresizingMaskIntoConstraints = false
        backGroundImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        backGroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        backGroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        backGroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        backGroundImageView.image = UIImage(named: "ice.png")
    }
    @IBAction func rinkButton(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "rinkSegue", sender: self)
    }
    
    
}

